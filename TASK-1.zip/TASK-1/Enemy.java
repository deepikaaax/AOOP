public interface Enemy {
    void attack();
}
