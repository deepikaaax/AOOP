public class Zombie implements Enemy {
    @Override
    public void attack() {
        System.out.println("Zombie attacks with a slow bite!");
    }
}
