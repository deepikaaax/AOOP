public class Alien implements Enemy {
    @Override
    public void attack() {
        System.out.println("Alien attacks with a laser beam!");
    }
}
