public interface GameItemsFactory {
    String getWeapon();
    String getPowerUp();
}
